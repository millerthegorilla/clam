This directory contains test that consist in a lot of random operation.
You should choose this directory for a test when:
- It is not deterministic
- It is not supervised (ie. no human interaction)
- It last too much to be executed each recompile.

