This directory should contain dedicated tests for the CLAM-Classes 

