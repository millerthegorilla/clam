This directory will contain any script that should be automatically passed throught
the source repository in order to locate anomalies.

