Functional tests of processings.
These tests should only involve configuring, feeding and checking the
output of a processing.
