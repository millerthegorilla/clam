Functional tests of applications (use of fa�ade classes is likely)
note that functional processing tests goes to ../ProcessingTests directory