This directory contains test that logs the efficiency of certain
parts of CLAM source.
TODO: Tests here should fullfill a log protocol (to be determined) 
so the web interface should read it.


