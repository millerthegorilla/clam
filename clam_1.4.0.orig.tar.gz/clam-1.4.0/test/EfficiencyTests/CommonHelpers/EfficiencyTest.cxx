#include "EfficiencyTest.hxx"

void EfficiencyTest::start()
{
	for (int i=4000; i--; )
		_testimony++;
}
void EfficiencyTest::stop()
{
	for (int i=4000; i--; )
		_testimony++;
}



