#ifndef __TESTCASES__
#define __TESTCASES__

namespace CLAMDraft
{

void TestBindingProcessingAdapter();

void TestAttachPresentationAdapter();

void TestControlUpdating();

void TestSeveralControlsUpdating();

}

#endif // TestCases.hxx

