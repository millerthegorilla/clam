All Processing classes for Audio File IO
