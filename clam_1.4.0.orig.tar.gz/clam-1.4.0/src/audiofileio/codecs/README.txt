Tools for AudioIO from sound file.
