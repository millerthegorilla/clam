
#include "TypedInControl.hxx"
