System-level classes such as multithreading, GUI-Processing interaction, etc
