System-level classes to handle multithreading transparently.
