Windows specific Application classes.
