Application classes that maybe used as helpers for developing a CLAM application.
