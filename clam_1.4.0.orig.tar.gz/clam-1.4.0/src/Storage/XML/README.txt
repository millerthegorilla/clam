Storage classes for XML: The storage, the xml storable interface, adapters
and helper clases.
