Base, structural classes for all storage classes.
