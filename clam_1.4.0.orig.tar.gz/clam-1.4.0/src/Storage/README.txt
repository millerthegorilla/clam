Diskstorage classes for XML, SDIF, ..
