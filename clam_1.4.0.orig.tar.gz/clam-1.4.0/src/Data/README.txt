Processing data storage classes such as Spectrum, etc
