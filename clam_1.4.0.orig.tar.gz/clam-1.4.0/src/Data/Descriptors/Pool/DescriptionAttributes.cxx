#include "DescriptionAttributes.hxx"
namespace CLAM
{
	
		AbstractAttribute::~AbstractAttribute()
		{
		}
}
