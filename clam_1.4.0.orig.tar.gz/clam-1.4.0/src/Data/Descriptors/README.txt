Processing data classes used for storing higher-level descriptions associated to basic processing data classes
