Concrete processing data storage classes such as Spectrum, Audio, etc
