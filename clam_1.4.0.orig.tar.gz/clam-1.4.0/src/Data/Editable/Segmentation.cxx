#include "Segmentation.hxx"


namespace CLAM
{
	Segmentation::~Segmentation()
	{
	}
}



