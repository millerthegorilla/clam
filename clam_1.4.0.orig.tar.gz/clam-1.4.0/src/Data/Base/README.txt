Basic structural classes for all processing data
