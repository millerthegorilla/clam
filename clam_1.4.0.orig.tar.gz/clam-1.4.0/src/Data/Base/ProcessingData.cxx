#include "ProcessingData.hxx"

namespace CLAM
{
	ProcessingData::~ProcessingData()
	{
	}
}


