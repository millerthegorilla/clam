#include "ProcessingDataConfig.hxx"


namespace CLAM
{
	ProcessingDataConfig::~ProcessingDataConfig()
	{
	}
}
